// Data Produk Mockup
const products = [
    {
        id: 1,
        name: "Midi Dress Linen Bitu",
        price: 355000,
        image: "gambar/product-1.jpeg",
        desc: "Dress berbahan linen premium yang nyaman dipakai sehari-hari. Potongan elegan cocok untuk acara santai maupun semi-formal."
    },
    {
        id: 2,
        name: "Blouse Casual White",
        price: 185000,
        image: "gambar/product-2.jpeg",
        desc: "Blouse putih dengan bahan katun jepang. Sangat adem dan tidak menerawang."
    },
    {
        id: 3,
        name: "Summer Floral Dress",
        price: 420000,
        image: "gambar/product-3.jpeg",
        desc: "Dress motif bunga dengan warna cerah. Cocok untuk liburan musim panas."
    },
    {
        id: 4,
        name: "Denim Jacket Classic",
        price: 299000,
        image: "gambar/product-4.jpeg",
        desc: "Jaket denim klasik yang tak lekang oleh waktu. Durable dan stylish."
    }
];

let currentProduct = null;
let selectedSize = 'M';
let cart = [];

// Fungsi Render Produk di Slide 2
function renderProducts() {
    const grid = document.getElementById('productGrid');
    grid.innerHTML = '';
    products.forEach(product => {
        grid.innerHTML += `
            <div class="product-card" onclick="openProduct(${product.id})">
                <img src="${product.image}" alt="${product.name}" class="product-img">
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <div class="product-price">Rp ${product.price.toLocaleString()}</div>
                </div>
            </div>
        `;
    });
}

// Navigasi Slide
function goToSlide(slideId) {
    document.querySelectorAll('.slide').forEach(s => s.classList.remove('active'));
    document.getElementById(`slide-${slideId}`).classList.add('active');
    window.scrollTo(0, 0);
}

// Buka Detail Produk (Slide 3)
function openProduct(id) {
    currentProduct = products.find(p => p.id === id);
    
    if(currentProduct) {
        document.getElementById('detailImg').src = currentProduct.image;
        document.getElementById('detailName').innerText = currentProduct.name;
        document.getElementById('detailPrice').innerText = "Rp " + currentProduct.price.toLocaleString();
        document.getElementById('detailDesc').innerText = currentProduct.desc;
        
        // Reset size selection to M
        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.classList.remove('selected');
            if(btn.innerText === 'M') {
                btn.classList.add('selected');
            }
        });
        selectedSize = 'M';
        
        goToSlide(3);
    }
}

// Pilih Ukuran
function selectSize(btn) {
    document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedSize = btn.innerText;
}

// Toggle Search Overlay
function toggleSearch() {
    const searchOverlay = document.getElementById('searchOverlay');
    searchOverlay.classList.toggle('active');
    
    if(searchOverlay.classList.contains('active')) {
        document.getElementById('searchInput').focus();
    } else {
        document.getElementById('searchInput').value = '';
        document.getElementById('searchResults').innerHTML = '';
    }
}

// Search Products
function searchProducts() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    const results = document.getElementById('searchResults');
    
    if(query.length === 0) {
        results.innerHTML = '';
        return;
    }
    
    const filtered = products.filter(p => 
        p.name.toLowerCase().includes(query)
    );
    
    if(filtered.length === 0) {
        results.innerHTML = '<p style="text-align:center; color:#999; padding:2rem;">Produk tidak ditemukan</p>';
        return;
    }
    
    results.innerHTML = filtered.map(product => `
        <div class="search-item" onclick="openProduct(${product.id}); toggleSearch();">
            <img src="${product.image}" alt="${product.name}">
            <div>
                <h4>${product.name}</h4>
                <p style="color: var(--primary-color); font-weight: 700;">Rp ${product.price.toLocaleString()}</p>
            </div>
        </div>
    `).join('');
}

// Toggle Cart Sidebar
function toggleCart() {
    const cartSidebar = document.getElementById('cartSidebar');
    cartSidebar.classList.toggle('active');
}

// Update Cart Badge
function updateCartBadge() {
    document.getElementById('cartBadge').innerText = cart.length;
}

// Add to Cart
function addToCart() {
    if(!currentProduct) return;
    
    const existingItem = cart.find(item => 
        item.id === currentProduct.id && item.size === selectedSize
    );
    
    if(existingItem) {
        alert('Produk dengan ukuran ini sudah ada di keranjang!');
        return;
    }
    
    cart.push({
        id: currentProduct.id,
        name: currentProduct.name,
        price: currentProduct.price,
        image: currentProduct.image,
        size: selectedSize
    });
    
    updateCartBadge();
    renderCart();
    toggleCart();
    
    // Show notification
    alert(`${currentProduct.name} (Size: ${selectedSize}) telah ditambahkan ke keranjang!`);
}

// Render Cart
function renderCart() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    const checkoutBtn = document.getElementById('checkoutBtn');
    
    if(cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Keranjang masih kosong</p>';
        cartTotal.innerText = 'Rp 0';
        checkoutBtn.disabled = true;
        return;
    }
    
    checkoutBtn.disabled = false;
    
    let total = 0;
    cartItems.innerHTML = cart.map((item, index) => {
        total += item.price;
        return `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-info">
                    <h4>${item.name}</h4>
                    <p>Ukuran: ${item.size}</p>
                    <div class="cart-item-price">Rp ${item.price.toLocaleString()}</div>
                    <span class="remove-item" onclick="removeFromCart(${index})">
                        <i class="fas fa-trash"></i> Hapus
                    </span>
                </div>
            </div>
        `;
    }).join('');
    
    cartTotal.innerText = 'Rp ' + total.toLocaleString();
}

// Remove from Cart
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartBadge();
    renderCart();
}

// Go to Checkout from Cart
function goToCheckout() {
    if(cart.length === 0) return;
    
    toggleCart();
    
    // Render checkout items
    const checkoutItems = document.getElementById('checkoutItems');
    checkoutItems.innerHTML = cart.map(item => `
        <div class="checkout-item">
            <img src="${item.image}">
            <div>
                <div style="font-weight: bold; font-size: 0.9rem;">${item.name}</div>
                <div style="font-size: 0.8rem; color: #666;">Size: ${item.size}</div>
                <div style="color: var(--primary-color); font-weight: 700;">Rp ${item.price.toLocaleString()}</div>
            </div>
        </div>
    `).join('');
    
    // Calculate totals
    const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
    const ongkir = 20000;
    const diskon = 10000;
    const total = subtotal + ongkir - diskon;
    
    document.getElementById('summarySubtotal').innerText = 'Rp ' + subtotal.toLocaleString();
    document.getElementById('summaryTotal').innerText = 'Rp ' + total.toLocaleString();
    
    goToSlide(4);
}

// Buy Now (langsung dari detail produk)
function buyNow() {
    if(!currentProduct) return;
    
    // Clear cart dan tambahkan produk saat ini
    cart = [{
        id: currentProduct.id,
        name: currentProduct.name,
        price: currentProduct.price,
        image: currentProduct.image,
        size: selectedSize
    }];
    
    updateCartBadge();
    goToCheckout();
}

// Process Order
function processOrder() {
    const name = document.getElementById('customerName').value;
    const address = document.getElementById('customerAddress').value;
    const phone = document.getElementById('customerPhone').value;
    const payment = document.getElementById('paymentMethod').value;
    
    // Create order summary
    const orderInfo = document.getElementById('orderInfo');
    const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
    const total = subtotal + 20000 - 10000;
    
    orderInfo.innerHTML = `
        <p><strong>Nama:</strong> ${name}</p>
        <p><strong>Alamat:</strong> ${address}</p>
        <p><strong>Telepon:</strong> ${phone}</p>
        <p><strong>Pembayaran:</strong> ${payment}</p>
        <hr style="margin: 1rem 0;">
        <p><strong>Produk yang dipesan:</strong></p>
        ${cart.map(item => `<p>• ${item.name} (${item.size}) - Rp ${item.price.toLocaleString()}</p>`).join('')}
        <hr style="margin: 1rem 0;">
        <p><strong>Total Pembayaran:</strong> Rp ${total.toLocaleString()}</p>
    `;
    
    // Clear cart
    cart = [];
    updateCartBadge();
    renderCart();
    
    // Reset form
    document.getElementById('checkoutForm').reset();
    
    goToSlide(5);
}

// Send Message (Contact Form)
function sendMessage() {
    alert('Terima kasih! Pesan Anda telah dikirim. Kami akan menghubungi Anda segera.');
    event.target.reset();
}

// Inisialisasi awal
window.onload = function() {
    renderProducts();
    updateCartBadge();
    renderCart();
}

// Close overlays when clicking outside
document.addEventListener('click', function(event) {
    const searchOverlay = document.getElementById('searchOverlay');
    const cartSidebar = document.getElementById('cartSidebar');
    
    // Close search if clicking on the overlay background
    if(event.target === searchOverlay) {
        toggleSearch();
    }
    
    // Close cart if clicking outside
    if(cartSidebar.classList.contains('active') && 
       !cartSidebar.contains(event.target) && 
       !event.target.closest('.fa-shopping-cart')) {
        toggleCart();
    }
});